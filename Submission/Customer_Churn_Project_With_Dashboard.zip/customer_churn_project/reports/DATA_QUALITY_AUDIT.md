# Data quality and leakage audit

Source: institute-provided synthetic customer churn workbook, exported to `customer_churn_raw.csv`.

- Shape: 8,000 rows × 27 original columns
- Duplicate rows: 0; duplicate CustomerIDs: 0
- Missing cells: 464; missing target labels: 0
- Missing by field: {'OnlineBackup': 62, 'AvgMonthlyDataUsageGB': 101, 'SatisfactionScore': 202, 'DaysSinceLastContact': 99}
- Negative MonthlyCharges: 0; negative TotalCharges: 0
- SatisfactionScore non-null range: 1 to 5
- Churn Yes: 1,440; No: 6,560

## Decisions
1. Do not drop rows with missing features; retain original missingness in SQL/BI export.
2. Exclude `CustomerID` and target-derived `ChurnFlag` from predictive features.
3. Fit numerical median imputation, scaling, categorical most-frequent imputation, and one-hot encoding inside training-only pipelines.
4. Stratify train/test (80/20) and use five-fold stratified training CV for model selection.
5. Check whether `ComplaintRaised`, `DaysSinceLastContact`, `SatisfactionScore`, and `TotalCharges` are available at prediction time; remove any feature recorded after churn before deployment.
6. Class imbalance: 18% churn; report recall, precision, F1 and ROC-AUC alongside accuracy.
7. Model probabilities may not be calibrated (especially with class weights); validate calibration and decision thresholds using training-only validation before business use.
8. Fairness: audit `Gender` and `SeniorCitizen` effects and subgroup performance before deployment.
9. No production claim: source is synthetic, and no temporal or external validation is available.

## Important clarification
The cleaned export is a *validated* dataset, not a fully imputed dataset. Nulls remain intentionally to prevent leakage. SQL and Power BI must explicitly handle blanks.
