# Verified descriptive insights and potential actions

| Segment | Observed churn | Suggested investigation |
|---|---:|---|
| Month-to-month contract | 27.83% | Test whether renewal or loyalty offers reduce churn |
| One-year contract | 7.41% | Compare tenure and customer mix |
| Two-year contract | 3.72% | Explore longer-term retention associations |
| Complaint raised = Yes | 49.42% | Review complaint resolution and contact follow-up |
| Complaint raised = No | 15.84% | Establish comparison baseline |
| Fiber optic | 21.86% | Investigate satisfaction and service issues |

Rates are observational associations from synthetic data, not causal effects. A retention pilot should be randomized and evaluated on incremental churn reduction and net benefit. Do not treat predicted probabilities as calibrated until verified.
