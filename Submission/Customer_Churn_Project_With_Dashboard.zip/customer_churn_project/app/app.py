"""Educational Streamlit churn-risk demo. Run from project root: streamlit run app/app.py"""
from pathlib import Path
import pandas as pd
import joblib
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
st.set_page_config(page_title="Telecom Churn Risk", page_icon="📊", layout="wide")
st.title("Telecom Customer Churn Risk Explorer")
st.caption("Educational demonstration using synthetic data; predictions are not validated for real customer decisions.")
@st.cache_resource
def load_model():
    return joblib.load(ROOT / "models" / "churn_pipeline.joblib")
@st.cache_data
def load_data():
    return pd.read_csv(ROOT / "data" / "customer_churn_clean.csv")
try:
    model = load_model()
    data = load_data()
except Exception as exc:
    st.error(f"Project files unavailable: {exc}")
    st.stop()
features = list(model.feature_names_in_)
st.sidebar.header("Example customer")
row_index = st.sidebar.number_input("Select example row", min_value=0, max_value=len(data)-1, value=0)
example = data.iloc[[int(row_index)]][features].copy()
st.subheader("Customer features (editable)")
with st.form("customer"):
    updates={}
    cols=st.columns(3)
    for idx,col in enumerate(features):
        value=example.iloc[0][col]
        with cols[idx%3]:
            if pd.api.types.is_numeric_dtype(data[col]):
                default=float(value) if pd.notna(value) else float(data[col].median())
                updates[col]=st.number_input(col, value=default)
            else:
                options=sorted(data[col].dropna().astype(str).unique().tolist())
                initial=str(value) if pd.notna(value) else (options[0] if options else "")
                updates[col]=st.selectbox(col, options=options, index=options.index(initial) if initial in options else 0)
    submit=st.form_submit_button("Estimate churn risk", type="primary")
if submit:
    input_row=pd.DataFrame([updates],columns=features)
    probability=float(model.predict_proba(input_row)[0,1])
    prediction=int(probability>=0.5)
    st.metric("Estimated churn probability", f"{probability:.1%}")
    st.progress(probability)
    st.write("Predicted class at threshold 0.50:", "Churn" if prediction else "Retained")
    st.info("A probability is not a guarantee. This is a model demonstration, not a real-world retention decision.")
st.divider()
st.subheader("Dataset overview")
a,b,c=st.columns(3)
a.metric("Customers",f"{len(data):,}")
b.metric("Observed churn rate",f"{data.ChurnFlag.mean():.1%}")
c.metric("Missing cells",f"{data.isna().sum().sum():,}")
st.bar_chart(data.groupby('ContractType')['ChurnFlag'].mean())
st.subheader("Model comparison")
st.dataframe(pd.read_csv(ROOT/'reports'/'model_comparison.csv'),hide_index=True)
