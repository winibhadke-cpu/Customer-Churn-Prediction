# Streamlit application

From the project root on Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app/app.py
```

Use the form to modify an example customer's features and calculate model-estimated churn risk. The saved model expects exactly the training feature names. The app uses synthetic data and is for demonstration only. Do not use predictions for real customer decisions without temporal, fairness and external validation.
